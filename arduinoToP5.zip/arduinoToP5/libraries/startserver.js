#!/usr/bin/env node

var serialserver = require('./p5.serialserver');
serialserver.start();
console.log("p5.serialserver is running");
